main file to run this code is Graph.java
example: 4-number of nodes/vertices, 6-number of edges. 
number of nodes should be greater than 1.
java Graph 4 6

A jar file is also available to test. Test from jar file
java -jar graph.jar 4 6

 Random weight was generated from 1 to number of nodes from input
 Default value of nodes=4 and edges=4.
 
 eccentricity was calculated for each vertices.
 
  